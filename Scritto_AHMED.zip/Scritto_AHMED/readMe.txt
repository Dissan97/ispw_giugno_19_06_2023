Esame scritto di Ingegneria del software e progettazione web
Gruppo A:

esercizio1: UseCaseExam-1.pdf
esercizio2: sq_diagram.pdf
